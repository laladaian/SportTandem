package main.java.unifr.tandem.action;

public interface CyberCoach {
    public static final String  BASE_URI = "http://diufvm31.unifr.ch:8090/CyberCoachServer/resources/";
    public static final String REL_PATH = "/CyberCoachServer/resources/";
    public static final String  RES_USERS = "users";
}
