INSERT INTO USER_PREFERENCES (username, password, realname, email, city, phone, frequency, sport, sportLevel, age)
                      values ('alice', 'asdf', 'Alice White', 'alice@test.com', 'Fribourg', '123-234-567', 'Daily', 'Badminton', 3, 22);
INSERT INTO USER_PREFERENCES (username, password, realname, email, city, phone, frequency, sport, sportLevel, age, comments)
                      values ('jack', 'asdf', 'Jack White', 'jack@test.com', 'Fribourg', '123-234-567', 'Daily', 'Badminton', 3, 22, 'would prefer to meet on Monday and Wednesday');
INSERT INTO USER_PREFERENCES (username, password) values ('bob', 'sdfv');
INSERT INTO USER_PREFERENCES (username, password) values ('john', 'cvbcv');
INSERT INTO USER_PREFERENCES (username, password) values ('timon', 'nffgg');